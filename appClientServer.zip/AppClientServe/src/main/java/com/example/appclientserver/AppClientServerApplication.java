package com.example.appclientserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppClientServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(AppClientServerApplication.class, args);
    }

}
