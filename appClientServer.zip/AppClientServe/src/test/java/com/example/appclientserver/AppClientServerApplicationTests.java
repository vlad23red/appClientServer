package com.example.appclientserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppClientServerApplicationTests {

    @Test
    void contextLoads() {
    }

}
